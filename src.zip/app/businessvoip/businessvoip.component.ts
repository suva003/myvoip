import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-businessvoip',
  templateUrl: './businessvoip.component.html',
  styleUrls: ['./businessvoip.component.css']
})
export class BusinessvoipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
